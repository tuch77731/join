helm upgrade --cleanup-on-fail \
  --install jupyter-hub jupyterhub/jupyterhub \
  --namespace jhub \
  --create-namespace \
  --version=1.1.4 \
  --values config.yaml \
  --set-file hub.extraFiles.my_config.stringData=./01_my_jupyterhub_config.py
