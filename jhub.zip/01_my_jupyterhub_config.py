from kubespawner import KubeSpawner
from ldap3 import Server, Connection


class AICKubeSpawner(KubeSpawner):
    # async def pre_spawn_hook(self):
    #    # print(spawner.user.encrypted_auth_state,111)
    #    auth_state = await self.user.get_auth_state()
    #    server = Server('10.23.215.31', use_ssl=True)
    #    print(auth_state,"hello")
    #    with Connection(server, auto_bind=True) as conn:
    #        conn.search('dc=aic,dc=cmuh,dc=org,dc=tw', f'(memberuid={spawner.user.name})', attributes=['gidNumber'])
    #        gids = [gid for entry in conn.entries for gid in entry.entry_attributes_as_dict['gidNumber']]
    #

    #    spawner.environment = {
    #      "NB_GID": str(auth_state["gidNumber"][0]),
    #      "NB_UID": str(auth_state['uidNumber'][0]),
    #      "NB_USER": auth_state['uid'][0],
    #      "NB_GROUPS": '|'.join([str(i) for i in gids]),
    #      "HOME": f"/home/{spawner.user.name}",
    #      "JUPYTER_ALLOW_INSECURE_WRITES": "true"}

    def options_form(self, a):
        return '''
                  <table style="width:100%">
                  <tr><td>
                    <div>
                      <a target="_blank" href="https://docs.google.com/spreadsheets/d/1tzgG8FwV_gqw1FaK4udtJjXvoZXOV7dA7KnYAZyaFrw/edit#gid=0">GPU Use Table</a>
                    </div>
                  </td></tr>
                  <tr><td>
                  <div class="h3" style="text-align:center">Image</div>
                  <div>
                  <select id="image" 
                          name="image"  
                          class="form-control" 
                          style="text-align:center;font-size:30px;height:50px">
                  <option value="10.23.215.31:17180/aic-jupyterhub/aic-base-git:1.3">aic1.3-base (20220527)</option> 
                  <option value="10.23.215.31:17180/aic-jupyterhub/aic-tensorflow:1.3">aic1.3-tensorflow2.8.0 (20220527)</option> 
                  <option value="10.23.215.31:17180/aic-jupyterhub/aic-pytorch:1.5">aic1.5-pytorch1.11.0 (20220606)</option>
                  <option value="10.23.215.31:17180/aic-jupyterhub/aic-pytorch:1.4">aic1.4-pytorch1.11.0 (20220606)</option>
                  <option value="10.23.215.31:17180/aic-jupyterhub/aic-pytorch:1.3">aic1.3-pytorch1.9.1 (20220527)</option> 
                  <option value="10.23.215.31:17180/aic-jupyterhub/aic-base-opencv-pytorch:1.0">aic-opencv-gpu4.5.2-pytorch1.9.1 (20211006)</option> 
                  <option value="10.23.215.31:17180/aic-jupyterhub/local-colab-fold:1.3">local-colab-fold (20220519)</option>
                  <option value="10.23.215.31:17180/aic-jupyterhub/aic-gene:1.4">aic1.4-gene (20220928)</option>
                  <option value="10.23.215.31:17180/aic-jupyterhub/aic-pathology:1.1">aic1.1-pathology (20220815)</option>
                  
                  <option  value="test:1.2">old-aic(no Zsh)</option>
                  <option  value="10.23.215.31:17180/aic-jupyterhub/test:1.3gene2">old-aic-base-gene(no Zsh)</option>

                  </select>
                    </div>
                  </td></tr>
                   <tr><td> 
                    <div class="h3" style="text-align:center">Node</div>
                    <div style="display:flex; justify-content:center">
                    <label class="radio-inline">
                      <input type="radio" name="node"  value="DGX1" checked> DGX1
                    </label>
                    <label class="radio-inline">
                      <input type="radio" name="node"  value="DGX2"> DGX2
                    </label>

                    </div>
                 </td></tr>
                 <tr><td>
                    <div class="h3" style="text-align:center">GPU</div>
                    <div style="display:flex; justify-content:center">
                        <label class="radio-inline">
                          <input type="radio" name="gpus" id="inlineRadio1" value="0" checked> 0
                        </label>
                        <label class="radio-inline">
                          <input type="radio" name="gpus" id="inlineRadio1" value="1"> 1
                        </label>
                        <label class="radio-inline">
                          <input type="radio" name="gpus" id="inlineRadio2" value="2"> 2
                        </label>
                        <label class="radio-inline">
                          <input type="radio" name="gpus" id="inlineRadio3" value="3"> 3
                        </label>
                        <label class="radio-inline">
                          <input type="radio" name="gpus" id="inlineRadio4" value="4"> 4
                        </label>
                    </div>
                 </td></tr>
                 <tr><td>
                    <div class="h3" style="text-align:center">CPU</div>
                    <div style="display:flex; justify-content:center">
                        <label class="radio-inline">
                          <input type="radio" name="cpus" id="inlineRadio1" value="2" checked> 2
                        </label>
                        <label class="radio-inline">
                          <input type="radio" name="cpus" id="inlineRadio1" value="4"> 4
                        </label>
                        <label class="radio-inline">
                          <input type="radio" name="cpus" id="inlineRadio2" value="8"> 8
                        </label>
                        <label class="radio-inline">
                          <input type="radio" name="cpus" id="inlineRadio3" value="16"> 16
                        </label>
                        <label class="radio-inline">
                          <input type="radio" name="cpus" id="inlineRadio4" value="32"> 32
                        </label>
                    </div>
                 </td></tr>
                  <tr><td>
                    <div class="h3" style="text-align:center">Shell</div>
                    <div style="display:flex; justify-content:center">
                      <label class="radio-inline">
                        <input type="radio" name="shell"  value="/bin/bash" checked> Bash
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="shell"  value="/bin/zsh"> Zsh
                      </label>
                    </div>
                  </td></tr>
                  <tr><td>
                    <div class="h3" style="text-align:center">Notebook_base_dir</div>
                    <div style="display:flex; justify-content:center">

                      <label class="radio-inline">
                        <input type="radio" name="notebook_dir"  value="~" checked> Home
                      </label>
                       <label class="radio-inline">
                        <input type="radio" name="notebook_dir"  value="/home" > Everybody Home
                      </label>                   
                     </div>
                  </td></tr>                 
               </table>
               '''
        # <option value = "10.23.215.31:17180/aic-jupyterhub/aic-tensorflow:1.1" > aic1.0-pytorch1.9.1 with git UI(20220509) </option >

    async def options_from_form(self, form):
        auth_state = await self.user.get_auth_state()
        server = Server('10.23.215.31', use_ssl=True)
        with Connection(server, auto_bind=True) as conn:
            conn.search('dc=aic,dc=cmuh,dc=org,dc=tw',
                        f'(memberuid={self.user.name})', attributes=['gidNumber'])
            gids = [
                gid for entry in conn.entries for gid in entry.entry_attributes_as_dict['gidNumber']]

        print(auth_state, "hello")
        my_user_options = dict()
        my_env = {
            "NB_GID": str(auth_state["gidNumber"][0]),
            "NB_UID": str(auth_state['uidNumber'][0]),
            "NB_USER": auth_state['uid'][0],
            "NB_GROUPS": '|'.join([str(i) for i in gids]),
            "HOME": f"/home/{auth_state['uid'][0]}",
            "JUPYTER_ALLOW_INSECURE_WRITES": "true"
        }

        my_env['SHELL'] = form.get('shell', ['/bin/bash'])[0]
        my_user_options['image'] = form.get('image')[0]
        my_user_options['node'] = form.get('node')[0]
        my_user_options['notebook_dir'] = form.get('notebook_dir')[0]
        if int(form.get('gpus', ['0'])[0]) > 0:
            my_user_options['extra_resource_limits'] = {
                "nvidia.com/gpu": form.get('gpus')[0]}
        else:
            my_env["NVIDIA_VISIBLE_DEVICES"] = 'none'

        my_user_options['cpus'] = form.get('cpus')[0]
        my_user_options['extra_environment'] = my_env
        return my_user_options

    @property
    def start_timeout(self):
        return 60

    @property
    def notebook_dir(self):
        return self.user_options.get('notebook_dir', '~')

    @property
    def node_selector(self):
        return {"gpu-type": self.user_options.get('node', 'DGX1')}

    @property
    def cpu_guarantee(self):
        return 2

    @property
    def cpu_limit(self):
        cpuLimit = self.user_options.get('cpus', 2)
        return cpuLimit

    @property
    def mem_guarantee(self):
        return '16G'

    @property
    def mem_limit(self):
        mynode = self.user_options.get('node', 'DGX1')
        if mynode == 'DGX1':
            return '128G'
        if mynode == 'DGX2':
            return '256G'
        return '64G'

    @property
    def environment(self):
        my_env = {}
        for k, v in self.user_options.get('extra_environment', {}).items():
            my_env[k] = v
        print(my_env)
        return my_env

    @property
    def image(self):
        myimage = '10.23.215.31:17180/aic-jupyterhub/aic-base:20210917'
        if self.user_options.get('image'):
            myimage = self.user_options['image']
        return myimage

    @property
    def extra_resource_guarantees(self):
        return self.user_options.get('extra_resource_limits', {})

    @property
    def extra_resource_limits(self):

        return self.user_options.get('extra_resource_limits', {})


c.JupyterHub.spawner_class = AICKubeSpawner
